const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const dir = path.resolve(__dirname, '../plugins/templater-obsidian');
const target = path.join(dir, 'main.js');
const marker = '// Templater local Vietnamese translation v1';
const source = fs.readFileSync(target, 'utf8');
if (source.includes(marker)) { console.log('Bản dịch đã được áp dụng.'); process.exit(0); }
const manifest = JSON.parse(fs.readFileSync(path.join(dir, 'manifest.json'), 'utf8'));
const entries = fs.readFileSync(path.join(__dirname, 'vi.txt'), 'utf8').split(/\r?\n/).filter(Boolean).map(line => {
  const i = line.indexOf('|');
  if (i < 1) throw new Error('Dòng từ điển không hợp lệ: ' + line);
  return [line.slice(0, i), line.slice(i + 1)];
});
let result = source, count = 0;
const missing = [];
for (const [en, vi] of entries) {
  const literals = [JSON.stringify(en)];
  if (en === ' in "Hotkeys" settings.') literals.push("'" + en + "'");
  if (!literals.some(literal => result.includes(literal))) { missing.push(en); continue; }
  for (const literal of literals) result = result.split(literal).join(JSON.stringify(vi));
  count++;
}
if (count < entries.length * 0.8) throw new Error('Phiên bản mới thay đổi quá nhiều; cần rà soát bản dịch trước khi áp dụng.');
result += '\n' + marker + '\n';
new vm.Script(result, { filename: target });
const backup = path.join(__dirname, 'backup-' + manifest.version + '-' + Date.now());
fs.mkdirSync(backup, { recursive: true });
for (const file of ['main.js', 'manifest.json', 'styles.css', 'data.json']) {
  if (fs.existsSync(path.join(dir, file))) fs.copyFileSync(path.join(dir, file), path.join(backup, file));
}
fs.writeFileSync(target, result, 'utf8');
console.log(`Đã Việt hóa ${count}/${entries.length} mục cho Templater ${manifest.version}. Sao lưu: ${backup}`);
if (missing.length) console.log('Các mục cần kiểm tra sau cập nhật: ' + missing.join('; '));
